@echo off
setlocal
title Peekr - Uninstall
set "DEST=%LOCALAPPDATA%\Peekr"
if exist "%DEST%\Peekr.dll" regsvr32 /s /u "%DEST%\Peekr.dll"
taskkill /f /im explorer.exe >nul 2>&1
timeout /t 1 /nobreak >nul
del /f /q "%DEST%\Peekr.dll" >nul 2>&1
rmdir "%DEST%" >nul 2>&1
del /f /q "%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1
start "" explorer.exe
echo Peekr has been removed.
pause
