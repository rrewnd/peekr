@echo off
setlocal
title Peekr - Install
set "DEST=%LOCALAPPDATA%\Peekr"
echo Installing Peekr...
if not exist "%DEST%" mkdir "%DEST%"
copy /Y "%~dp0Peekr.dll" "%DEST%\Peekr.dll" >nul
if errorlevel 1 (
  echo.
  echo Could not copy Peekr.dll. Run Uninstall.bat first, then try again.
  pause & exit /b 1
)
regsvr32 /s "%DEST%\Peekr.dll"
if errorlevel 1 ( echo Registration failed. & pause & exit /b 1 )
echo Refreshing thumbnails ^(Explorer will restart for a second^)...
taskkill /f /im explorer.exe >nul 2>&1
del /f /q "%LOCALAPPDATA%\Microsoft\Windows\Explorer\thumbcache_*.db" >nul 2>&1
start "" explorer.exe
echo.
echo Done! Open a folder with .psd files and switch to Medium or Large icons.
pause
