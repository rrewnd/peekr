PEEKR  -  PSD thumbnails in Windows Explorer
==========================================
1. Extract this whole folder (right-click the zip > Extract All).
2. Double-click Install.bat.
   - If Windows says "protected your PC": click More info > Run anyway.
3. Open a folder with .psd files and switch View to Medium / Large icons.

To remove it: double-click Uninstall.bat.
Trouble? See the full guide: README.md in the project page.
